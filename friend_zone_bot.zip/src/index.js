require("dotenv").config();

const express = require("express");
const { Bot, Keyboard, InlineKeyboard, session } = require("grammy");
const { Pool } = require("pg");

const required = ["BOT_TOKEN", "DATABASE_URL"];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}

const bot = new Bot(process.env.BOT_TOKEN);
const app = express();
app.get("/", (_req, res) => res.status(200).send("Friend Zone is running."));
app.get("/health", (_req, res) => res.status(200).json({ ok: true }));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: false } : undefined,
  max: 5
});

const mainKeyboard = new Keyboard()
  .text("🔎 ស្វែងរកមិត្ត").text("👤 Profile").row()
  .text("❤️ Matches").text("⚙️ សុវត្ថិភាព").resized();

const adminIds = new Set(
  (process.env.ADMIN_IDS || "").split(",").map(s => s.trim()).filter(Boolean)
);

const ageGroup = age => age < 18 ? "minor" : "adult";
const cleanText = (value, max = 250) =>
  String(value || "").replace(/[<>]/g, "").trim().slice(0, max);

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS profiles (
      user_id BIGINT PRIMARY KEY,
      username TEXT,
      nickname TEXT NOT NULL,
      age SMALLINT NOT NULL CHECK (age BETWEEN 13 AND 99),
      interests TEXT NOT NULL,
      bio TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      active BOOLEAN NOT NULL DEFAULT TRUE
    );
    CREATE TABLE IF NOT EXISTS likes (
      from_id BIGINT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
      to_id BIGINT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (from_id, to_id),
      CHECK (from_id <> to_id)
    );
    CREATE TABLE IF NOT EXISTS matches (
      user_a BIGINT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
      user_b BIGINT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (user_a, user_b),
      CHECK (user_a < user_b)
    );
    CREATE TABLE IF NOT EXISTS blocks (
      blocker_id BIGINT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
      blocked_id BIGINT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (blocker_id, blocked_id),
      CHECK (blocker_id <> blocked_id)
    );
    CREATE TABLE IF NOT EXISTS reports (
      id BIGSERIAL PRIMARY KEY,
      reporter_id BIGINT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
      reported_id BIGINT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
      reason TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      status TEXT NOT NULL DEFAULT 'open'
    );
    CREATE INDEX IF NOT EXISTS reports_status_idx ON reports(status);
  `);
}

async function getProfile(id) {
  const result = await pool.query(
    "SELECT * FROM profiles WHERE user_id=$1 AND active=TRUE", [String(id)]
  );
  return result.rows[0] || null;
}

async function blockedEitherWay(a, b) {
  const result = await pool.query(
    "SELECT 1 FROM blocks WHERE (blocker_id=$1 AND blocked_id=$2) OR (blocker_id=$2 AND blocked_id=$1) LIMIT 1",
    [String(a), String(b)]
  );
  return result.rowCount > 0;
}

function profileText(p) {
  return `👤 ${p.nickname}\n🎂 អាយុ: ${p.age}\n✨ ចំណាប់អារម្មណ៍: ${p.interests}\n📝 ${p.bio || "មិនទាន់សរសេរ Bio"}\n\n⚠️ កុំចែករំលែកលេខសម្ងាត់ ព័ត៌មានហិរញ្ញវត្ថុ ឬទីតាំងពិតជាមួយអ្នកមិនស្គាល់។`;
}

async function sendNextProfile(ctx) {
  const me = await getProfile(ctx.from.id);
  if (!me) return ctx.reply("សូមចុះឈ្មោះជាមុន ដោយវាយ /start");

  const result = await pool.query(`
    SELECT p.* FROM profiles p
    WHERE p.active=TRUE
      AND p.user_id <> $1
      AND (p.age < 18) = ($2 < 18)
      AND NOT EXISTS (SELECT 1 FROM likes l WHERE l.from_id=$1 AND l.to_id=p.user_id)
      AND NOT EXISTS (SELECT 1 FROM blocks b WHERE
        (b.blocker_id=$1 AND b.blocked_id=p.user_id) OR
        (b.blocker_id=p.user_id AND b.blocked_id=$1))
      AND NOT EXISTS (SELECT 1 FROM matches m WHERE
        (m.user_a=LEAST($1::bigint,p.user_id) AND m.user_b=GREATEST($1::bigint,p.user_id)))
    ORDER BY p.created_at DESC LIMIT 1
  `, [String(ctx.from.id), me.age]);

  if (!result.rows.length) {
    return ctx.reply("ឥឡូវនេះមិនមាន Profile ថ្មីសម្រាប់បង្ហាញទេ។ សូមសាកល្បងពេលក្រោយ។", { reply_markup: mainKeyboard });
  }

  const p = result.rows[0];
  const keyboard = new InlineKeyboard()
    .text("❤️ Like", `like:${p.user_id}`)
    .text("⏭️ រំលង", `skip:${p.user_id}`).row()
    .text("🚩 Report", `report:${p.user_id}`);
  await ctx.reply(profileText(p), { reply_markup: keyboard });
}

bot.use(session({
  initial: () => ({ step: null, draft: {} })
}));

bot.command("start", async ctx => {
  const profile = await getProfile(ctx.from.id);
  if (profile) {
    return ctx.reply(`សួស្តី ${profile.nickname}! 👋\nសូមប្រើ Menu ខាងក្រោមដើម្បីស្វែងរកមិត្តថ្មី។`, { reply_markup: mainKeyboard });
  }
  ctx.session.step = "nickname";
  ctx.session.draft = { username: ctx.from.username || null };
  await ctx.reply(
    "សួស្តី! 👋 សូមស្វាគមន៍មកកាន់ Friend Zone។\n\nBOT នេះសម្រាប់ស្វែងរកមិត្តថ្មីដោយការយល់ព្រមពីគ្នា។ អ្នកត្រូវមានអាយុយ៉ាងតិច 13 ឆ្នាំ។ សូមប្រើឈ្មោះហៅក្រៅ ហើយកុំបញ្ចូលព័ត៌មានឯកជន។\n\nសូមវាយឈ្មោះហៅក្រៅរបស់អ្នក:"
  );
});

bot.command("cancel", async ctx => {
  ctx.session.step = null;
  ctx.session.draft = {};
  await ctx.reply("បានបោះបង់។", { reply_markup: mainKeyboard });
});

bot.on("message:text", async ctx => {
  const text = ctx.message.text.trim();
  if (text.startsWith("/")) return;

  if (text === "🔎 ស្វែងរកមិត្ត") return sendNextProfile(ctx);
  if (text === "👤 Profile") {
    const p = await getProfile(ctx.from.id);
    if (!p) return ctx.reply("សូមវាយ /start ដើម្បីចុះឈ្មោះ។");
    const kb = new InlineKeyboard()
      .text("✏️ កែ Profile", "edit_profile")
      .text("🗑️ លុប Profile", "delete_profile");
    return ctx.reply(profileText(p), { reply_markup: kb });
  }
  if (text === "❤️ Matches") {
    const result = await pool.query(`
      SELECT p.nickname, p.username, p.age, p.interests
      FROM matches m
      JOIN profiles p ON p.user_id = CASE WHEN m.user_a=$1 THEN m.user_b ELSE m.user_a END
      WHERE (m.user_a=$1 OR m.user_b=$1) AND p.active=TRUE
      ORDER BY m.created_at DESC LIMIT 30
    `, [String(ctx.from.id)]);
    if (!result.rows.length) return ctx.reply("អ្នកមិនទាន់មាន Match ទេ។ សាកល្បង Like Profile មើល! ❤️");
    const lines = result.rows.map((p, i) =>
      `${i + 1}. ${p.nickname}, ${p.age} ឆ្នាំ\n   ✨ ${p.interests}\n   ${p.username ? "Telegram: @" + p.username : "អ្នកប្រើនេះមិនមាន username សាធារណៈទេ"}`
    );
    return ctx.reply("❤️ Matches របស់អ្នក\n\n" + lines.join("\n\n") + "\n\nសូមគោរពការយល់ព្រម និងកុំរំខានអ្នកដទៃ។");
  }
  if (text === "⚙️ សុវត្ថិភាព") {
    return ctx.reply(
      "🛡️ គន្លឹះសុវត្ថិភាព\n• កុំចែករំលែកលេខសម្ងាត់ ឬព័ត៌មានធនាគារ។\n• កុំផ្ញើប្រាក់ទៅមនុស្សដែលអ្នកមិនស្គាល់។\n• ប្រើ Report ប្រសិនបើមានការរំខាន។\n• ប្រើ /delete_me ដើម្បីលុបទិន្នន័យ Profile របស់អ្នក។\n• ប្រើ /block USER_ID មិនអាចធ្វើបានទេ ព្រោះ BOT មិនបង្ហាញ ID ឯកជន។ សូម Block តាមប៊ូតុង Report/Block ក្នុង Profile។"
    );
  }

  const step = ctx.session.step;
  if (!step) return;

  if (step === "nickname") {
    const nickname = cleanText(text, 32);
    if (nickname.length < 2) return ctx.reply("សូមបញ្ចូលឈ្មោះយ៉ាងតិច 2 តួអក្សរ។");
    ctx.session.draft.nickname = nickname;
    ctx.session.step = "age";
    return ctx.reply("សូមបញ្ចូលអាយុរបស់អ្នក (13–99) ជាលេខ:");
  }
  if (step === "age") {
    const age = Number(text);
    if (!Number.isInteger(age) || age < 13 || age > 99) return ctx.reply("អាយុមិនត្រឹមត្រូវទេ។ សូមបញ្ចូលលេខ 13–99។");
    ctx.session.draft.age = age;
    ctx.session.step = "interests";
    return ctx.reply("សូមសរសេរចំណាប់អារម្មណ៍របស់អ្នក (ឧ. ហ្គេម, តន្ត្រី, បាល់ទាត់):");
  }
  if (step === "interests") {
    const interests = cleanText(text, 180);
    if (interests.length < 2) return ctx.reply("សូមសរសេរចំណាប់អារម្មណ៍បន្តិច។");
    ctx.session.draft.interests = interests;
    ctx.session.step = "bio";
    return ctx.reply("សរសេរ Bio ខ្លីៗអំពីខ្លួនអ្នក ឬវាយ - ដើម្បីរំលង:");
  }
  if (step === "bio") {
    const bio = text === "-" ? "" : cleanText(text, 250);
    const d = ctx.session.draft;
    await pool.query(`
      INSERT INTO profiles(user_id, username, nickname, age, interests, bio)
      VALUES($1,$2,$3,$4,$5,$6)
      ON CONFLICT(user_id) DO UPDATE SET username=EXCLUDED.username,
        nickname=EXCLUDED.nickname, age=EXCLUDED.age, interests=EXCLUDED.interests,
        bio=EXCLUDED.bio, active=TRUE
    `, [String(ctx.from.id), d.username || null, d.nickname, d.age, d.interests, bio]);
    ctx.session.step = null;
    ctx.session.draft = {};
    return ctx.reply("រួចរាល់! 🎉 Profile របស់អ្នកត្រូវបានបង្កើត។ ចុច «🔎 ស្វែងរកមិត្ត» ដើម្បីចាប់ផ្តើម។", { reply_markup: mainKeyboard });
  }
});

bot.callbackQuery(/^skip:(\d+)$/, async ctx => {
  await ctx.answerCallbackQuery({ text: "បានរំលង" });
  await sendNextProfile(ctx);
});

bot.callbackQuery(/^like:(\d+)$/, async ctx => {
  const targetId = ctx.match[1];
  const fromId = String(ctx.from.id);
  if (targetId === fromId) return ctx.answerCallbackQuery({ text: "មិនអាច Like ខ្លួនឯងបានទេ។", show_alert: true });
  const me = await getProfile(fromId);
  const target = await getProfile(targetId);
  if (!me || !target) return ctx.answerCallbackQuery({ text: "Profile មិនមានទៀតទេ។", show_alert: true });
  if ((me.age < 18) !== (target.age < 18)) return ctx.answerCallbackQuery({ text: "មិនអាច Match រវាងក្រុមអាយុខុសគ្នាបានទេ។", show_alert: true });
  if (await blockedEitherWay(fromId, targetId)) return ctx.answerCallbackQuery({ text: "មិនអាចធ្វើសកម្មភាពលើ Profile នេះបានទេ។", show_alert: true });

  await pool.query("INSERT INTO likes(from_id,to_id) VALUES($1,$2) ON CONFLICT DO NOTHING", [fromId, targetId]);
  const mutual = await pool.query("SELECT 1 FROM likes WHERE from_id=$1 AND to_id=$2", [targetId, fromId]);
  if (mutual.rowCount) {
    const a = BigInt(fromId) < BigInt(targetId) ? fromId : targetId;
    const b = a === fromId ? targetId : fromId;
    await pool.query("INSERT INTO matches(user_a,user_b) VALUES($1,$2) ON CONFLICT DO NOTHING", [a, b]);
    await ctx.api.sendMessage(fromId, `🎉 អ្នកបាន Match ជាមួយ ${target.nickname}!\nសូមចូល «❤️ Matches» ដើម្បីមើលព័ត៌មានសាធារណៈ។`);
    await ctx.api.sendMessage(targetId, `🎉 អ្នកបាន Match ជាមួយ ${me.nickname}!\nសូមចូល «❤️ Matches» ដើម្បីមើលព័ត៌មានសាធារណៈ។`);
  } else {
    await ctx.answerCallbackQuery({ text: "បាន Like ❤️" });
  }
  await sendNextProfile(ctx);
});

bot.callbackQuery(/^report:(\d+)$/, async ctx => {
  const targetId = ctx.match[1];
  if (targetId === String(ctx.from.id)) return ctx.answerCallbackQuery({ text: "មិនអាច Report ខ្លួនឯងបានទេ។", show_alert: true });
  const kb = new InlineKeyboard()
    .text("Spam", `reportreason:${targetId}:spam`)
    .text("រំខាន", `reportreason:${targetId}:harassment`).row()
    .text("Profile ក្លែងក្លាយ", `reportreason:${targetId}:fake`)
    .text("ផ្សេងៗ", `reportreason:${targetId}:other`).row()
    .text("🚫 Block ផង", `block:${targetId}`);
  await ctx.answerCallbackQuery();
  await ctx.reply("សូមជ្រើសរើសមូលហេតុ Report:", { reply_markup: kb });
});

bot.callbackQuery(/^reportreason:(\d+):([a-z]+)$/, async ctx => {
  const targetId = ctx.match[1], reason = ctx.match[2];
  if (targetId === String(ctx.from.id)) return ctx.answerCallbackQuery();
  await pool.query(
    "INSERT INTO reports(reporter_id,reported_id,reason) VALUES($1,$2,$3)",
    [String(ctx.from.id), targetId, reason]
  );
  await ctx.answerCallbackQuery({ text: "បានផ្ញើ Report ទៅ Admin។" });
  await ctx.reply("អរគុណ។ Report របស់អ្នកត្រូវបានកត់ត្រា។");
});

bot.callbackQuery(/^block:(\d+)$/, async ctx => {
  const targetId = ctx.match[1], fromId = String(ctx.from.id);
  if (targetId === fromId) return ctx.answerCallbackQuery({ text: "មិនអាច Block ខ្លួនឯងបានទេ។", show_alert: true });
  const me = await getProfile(fromId), target = await getProfile(targetId);
  if (!me || !target) return ctx.answerCallbackQuery({ text: "មិនអាច Block បានទេ។", show_alert: true });
  await pool.query("INSERT INTO blocks(blocker_id,blocked_id) VALUES($1,$2) ON CONFLICT DO NOTHING", [fromId, targetId]);
  await pool.query("DELETE FROM matches WHERE user_a=LEAST($1::bigint,$2::bigint) AND user_b=GREATEST($1::bigint,$2::bigint)", [fromId, targetId]);
  await ctx.answerCallbackQuery({ text: "បាន Block។" });
  await ctx.reply("បាន Block Profile នេះ។ អ្នកទាំងពីរនឹងមិនត្រូវបានបង្ហាញឱ្យគ្នាទៀតទេ។");
});

bot.callbackQuery("edit_profile", async ctx => {
  ctx.session.step = "nickname";
  const p = await getProfile(ctx.from.id);
  ctx.session.draft = { username: ctx.from.username || null };
  await ctx.answerCallbackQuery();
  await ctx.reply(`កែ Profile (ចាប់ផ្តើមឡើងវិញ)។ ឈ្មោះបច្ចុប្បន្ន: ${p?.nickname || ""}\nសូមបញ្ចូលឈ្មោះហៅក្រៅថ្មី:`);
});

bot.callbackQuery("delete_profile", async ctx => {
  await ctx.answerCallbackQuery();
  const kb = new InlineKeyboard().text("បាទ/ចាស លុប Profile", "confirm_delete").text("បោះបង់", "cancel_delete");
  await ctx.reply("តើអ្នកប្រាកដថាចង់លុប Profile, Likes និង Matches របស់អ្នកទេ?", { reply_markup: kb });
});

bot.callbackQuery("confirm_delete", async ctx => {
  await pool.query("DELETE FROM profiles WHERE user_id=$1", [String(ctx.from.id)]);
  ctx.session.step = null;
  ctx.session.draft = {};
  await ctx.answerCallbackQuery({ text: "បានលុប" });
  await ctx.reply("បានលុប Profile និងទិន្នន័យពាក់ព័ន្ធ។ វាយ /start ប្រសិនបើអ្នកចង់ចុះឈ្មោះម្តងទៀត។");
});

bot.callbackQuery("cancel_delete", async ctx => {
  await ctx.answerCallbackQuery({ text: "បានបោះបង់" });
  await ctx.reply("មិនបានលុប Profile ទេ។", { reply_markup: mainKeyboard });
});

bot.command("delete_me", async ctx => {
  await pool.query("DELETE FROM profiles WHERE user_id=$1", [String(ctx.from.id)]);
  ctx.session.step = null;
  ctx.session.draft = {};
  await ctx.reply("បានលុប Profile និងទិន្នន័យដែលភ្ជាប់ជាមួយ។ វាយ /start ដើម្បីចុះឈ្មោះឡើងវិញ។");
});

bot.command("admin", async ctx => {
  if (!adminIds.has(String(ctx.from.id))) return ctx.reply("អ្នកមិនមានសិទ្ធិ Admin ទេ។");
  const result = await pool.query(`
    SELECT r.id, r.reporter_id, a.nickname AS reporter_name,
           r.reported_id, b.nickname AS reported_name, r.reason, r.created_at
    FROM reports r
    LEFT JOIN profiles a ON a.user_id=r.reporter_id
    LEFT JOIN profiles b ON b.user_id=r.reported_id
    WHERE r.status='open' ORDER BY r.created_at DESC LIMIT 20
  `);
  if (!result.rows.length) return ctx.reply("មិនមាន Report ថ្មីទេ។");
  const lines = result.rows.map(r =>
    `#${r.id} | ${r.reason}\nអ្នក Report: ${r.reporter_name || "Deleted"}\nProfile: ${r.reported_name || "Deleted"}\nReport ID: ${r.id}`
  );
  await ctx.reply("📋 Open Reports\n\n" + lines.join("\n\n"));
});

bot.catch(err => {
  console.error("Bot error:", err.error);
});

async function main() {
  await initDb();
  const server = app.listen(Number(process.env.PORT || 3000), () => {
    console.log(`Health server listening on port ${process.env.PORT || 3000}`);
  });
  // Start long polling without blocking registration of shutdown handlers.
  bot.start().catch(err => {
    console.error("Bot polling stopped with error:", err);
    process.exitCode = 1;
  });
  const shutdown = async () => {
    bot.stop();
    server.close();
    await pool.end();
    process.exit(0);
  };
  process.once("SIGINT", shutdown);
  process.once("SIGTERM", shutdown);
}

main().catch(err => {
  console.error("Startup failed:", err);
  process.exit(1);
});
